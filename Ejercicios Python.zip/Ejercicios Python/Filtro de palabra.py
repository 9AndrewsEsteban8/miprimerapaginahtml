palabra = input("Ingrese una palabra:")
for i in range(0,len(palabra)):
  print(palabra[i])


