num = float(input("Introduce tu edad:"))
if num >= 18:
  print("Eres mayor de edad")
else:
  print("Eres menor de edad")
